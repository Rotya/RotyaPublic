﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace egyszamjatek
{
    class Program
    {
        static void Main(string[] args)
        { 
            
            string[] adatok = File.ReadAllLines("egyszamjatek.txt");
            Console.WriteLine($"3. feladat: Jatekosok szama: {adatok.Length}");

            string[] asd = adatok[0].Split();
            Console.WriteLine($"4. feladat: Fordulok száma: {asd.Length - 1}");

            bool van = false;
            for (int i = 0; i < adatok.Length; i++)
            {
                string[] tmp = adatok[i].Split();
                if (tmp[0] == "1")
                    van = true;
            }
            Console.Write("5. feladat: ");
            Console.WriteLine(van ? "Az első fordulóban volt egyes tipp!" : "Az első fordulóban nem volt egyes tipp!");

            int max = 0;
            for (int i = 0; i < adatok.Length; i++)
            {
                string[] tmp = adatok[i].Split();
                for (int j = 0; j < tmp.Length - 1; j++)
                {
                    if (int.Parse(tmp[j]) > max)
                        max = int.Parse(tmp[j]);
                }
            }
            Console.WriteLine($"6. feladat: A legnagyobb tipp a fordulok soran: {max}");

            Console.Write($"7. feladat: Kerem a fordulo sorszamat [1-{asd.Length - 1}]: ");
            int beker = int.Parse(Console.ReadLine());

            Console.Write("8. feladat: ");
            int nyertespont = 0;
            if (beker > asd.Length - 1)
            {
                beker = 1;
            }
            List<int> lista1 = new List<int>();
            List<int> lista2 = new List<int>();
            for (int i = 0; i < adatok.Length; i++)
            {
                string[] tmp = adatok[i].Split(' ');
                if (!lista1.Contains(int.Parse(tmp[beker - 1])) && !lista2.Contains(int.Parse(tmp[beker - 1])))
                {
                    lista1.Add(int.Parse(tmp[beker - 1]));
                    lista2.Add(int.Parse(tmp[beker - 1]));
                }
                else
                {
                    lista1.Remove(int.Parse(tmp[beker - 1]));
                }
            }

            if (lista1.Count >= 1)
            {
                nyertespont = lista1.Min();
            }
            string szoveg;
            if(lista1.Count > 0)
                szoveg = "A nyertes tipp a megadott fordulóban: " + lista1.Min().ToString();
            else
                szoveg = "Nem volt egyedi tipp a megadott fordulóban!";
            Console.WriteLine(szoveg);

            Console.Write("9. feladat: ");
            if (beker > asd.Length - 1)
            {
                beker = 1;
            }
            StreamWriter sw = new StreamWriter("nyertes.txt");
            if (szoveg != "Nem volt egyedi tipp a megadott fordulóban!")
            {
                for (int i = 0; i < adatok.Length; i++)
                {
                    string[] tmp = adatok[i].Split(' ');
                    if (int.Parse(tmp[beker - 1]) == nyertespont)
                    {
                        sw.WriteLine($"Forduló sorszáma: {beker}. \n Nyertes tipp: {nyertespont} \n Nyertes játékos: {tmp[tmp.Length - 1]}" );
                        sw.Close();
                        Console.WriteLine("A megadott forduló nyertese: " + tmp[tmp.Length - 1]);
                    }
                }
            }
            else
            {
                sw.WriteLine("");
                sw.Close();
                Console.WriteLine("Nem volt nyertes a megadott fordulóban!"); 
            }
        }
    }
}
