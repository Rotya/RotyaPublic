﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Helsinki
{
    public class Adatok
    {
        public int Helyezes;
        public int Sorszam;
        public string Sportag;
        public string Versenyszam;
        public Adatok(string sor)
        {
            string[] tmp = sor.Split();
            Helyezes = int.Parse(tmp[0]); 
            Sorszam = int.Parse(tmp[1]);
            Sportag = tmp[2];
            Versenyszam = tmp[3];
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Adatok> lista = new List<Adatok>();
            var reader = File.ReadAllLines("helsinki.txt");

            foreach(var item in reader)
                lista.Add(new Adatok(item));
            Console.WriteLine($"3. feladat: \n Pontszerzo helyezesek szama: {lista.Count}");

            int arany = 0;
            int ezust = 0;
            int bronz = 0;
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].Helyezes == 1)
                    arany++;
                if (lista[i].Helyezes == 2)
                    ezust++;
                if (lista[i].Helyezes == 3)
                    bronz++;
            }
            Console.WriteLine($"4. feladat: \n Arany:{arany} \n Ezust: {ezust} \n Bronz: {bronz} \n Osszesen: {arany + ezust + bronz}");

            int olimpiaiPont = 0;
            int[] pontok = new int[] { 7, 5, 4, 3, 2, 1 };
            for (int i = 0; i < lista.Count; i++)
                olimpiaiPont += pontok[lista[i].Helyezes - 1];
            Console.WriteLine($"5. feladat: \n Olimpiai pontok szama: {olimpiaiPont}");

            int uszas = 0;
            int torna = 0;
            string szoveg;
            for (int i = 0; i < lista.Count; i++)
            {
                if(lista[i].Helyezes == 1 || lista[i].Helyezes == 2 || lista[i].Helyezes == 3)
                {
                    if (lista[i].Sportag == "torna")
                        torna++;
                    if (lista[i].Sportag == "uszas")
                        uszas++;
                }
            }
            if(torna > uszas)
                szoveg = "Torna sportagban szereztek tobb ermet";
            else if (uszas > torna)
                szoveg = "Uszas sportagban szereztek tobb ermet";
            else
                szoveg = "Egyenlo volt az ermek szama";
            Console.WriteLine($"6. feladat: \n {szoveg}");

            List<string> lista2 = new List<string>();
            foreach (var item in lista)
            {
                string sportag = item.Sportag;
                if (sportag == "kajakkenu")
                    sportag = "kajak-kenu";
                lista2.Add($"{item.Helyezes} {item.Sorszam} {sportag} {item.Versenyszam}");
            }
            File.WriteAllLines("helsinki2.txt", lista2);

            int max = 0;
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].Sorszam > lista[max].Sorszam)
                    max = i;
            }
            Console.WriteLine($"8. feladat: \n Helyezes: {lista[max].Helyezes} \n Sportag: {lista[max].Sportag} \n Versenyszam: {lista[max].Versenyszam} \n Sportolok szama: {lista[max].Sorszam}");
        }

    }
}
